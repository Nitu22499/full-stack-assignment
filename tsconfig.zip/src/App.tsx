import React from 'react'
import './App.css'
import { PageviewGenerator } from './PageviewGenerator'
// import { EventTable } from './EventTable'

function App() {
  return (
    <div className='App'>
      <header className='App-header'>
        <>
        
        <PageviewGenerator />
        {/* <EventTable/> */}
        </>
      </header>
    </div>
  )
}

export default App
