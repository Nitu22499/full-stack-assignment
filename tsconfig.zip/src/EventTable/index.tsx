import axios from 'axios'
import React, { useEffect, useState } from 'react'
// import 'bootstap/dist/css/bootstap.css'
// setevents([event,...events])
 
export const EventTable = (pageview) => {
    const [events, setevents] = useState()
    // console.log(events)
    useEffect(()=>{
        console.log("first")
        axios.get('http://13.234.120.153/api/events/')
        .then(res=>{
            // console.log(res.data)
            setevents(res.data)
        });
    },[]);

    // useEffect(()=>{
    //     console.log("second")
    //     console.log(pageview)
    //     console.log(events,typeof(events),typeof(pageview))
    //     events.unshift(pageview)
    //     // setevents([pageview,...events]);
    // },[pageview]);

    useEffect(() => setevents([pageview,...events]), [pageview]);

return <div>{
    !events ? ("No Events Generated"):(
        <table>
            <thead>
                <tr>
                    <th>Event ID</th>
                    <th>Event Date</th>
                    <th>Page Title</th>
                    <th>Page Description</th>
                    <th>Page Tags</th>
                    <th>User ID</th>
                    <th>User joined</th>
                </tr>
            </thead>
            <tbody>
                {
                    events.map((event, index)=>(
                        <tr key={index}>
                            <td>{event.event_id}</td>
                            <td>{event.event_date}</td>
                            <td>{event.page_title}</td>
                            <td>{event.page_description}</td>
                            <td>{event.page_tags}</td>
                            <td>{event.user_id}</td>
                            <td>{event.user_joined}</td>
                        </tr>
                    ))
                    }
            </tbody>
        </table>
    )
    }</div> 

}
  